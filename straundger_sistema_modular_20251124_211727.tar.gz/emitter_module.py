"""
Módulo de Alimentação Contínua (Emitter Module)
================================================

Responsabilidade: Emitir caixas continuamente em cada linha até que S2 seja ativado.
Quando S2 desliga (caixa saiu), imediatamente emite uma nova caixa.

Funciona de forma independente e modular.

Comunicação via Modbus TCP com Factory I/O
"""

import time
import argparse
import csv
import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

try:
    from pymodbus.client import ModbusTcpClient
except ImportError:
    from pymodbus.client.sync import ModbusTcpClient


UNIT = 1  # Slave ID padrão
SCAN_INTERVAL = 0.05  # 50ms entre leituras


# ---------------------------------------------------------------------------
# Utilitários de mapeamento (CSV do Factory I/O)
# ---------------------------------------------------------------------------

def _normalize_name(name: str) -> str:
    """Normaliza nomes para busca no dicionário"""
    if name is None:
        return ""
    name = name.replace("\\ufeff", "").strip().lower()
    name = re.sub(r"[^a-z0-9]+", "", name)
    return name


def load_factoryio_map(csv_path: str = "factory_tags.csv") -> Tuple[Dict[str, dict], Dict[str, dict]]:
    """
    Lê o CSV exportado do Factory I/O e separa entradas e saídas.
    Retorna dois dicionários: inputs_map e outputs_map
    """
    inputs: Dict[str, dict] = {}
    outputs: Dict[str, dict] = {}

    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Arquivo de mapeamento CSV não encontrado: {csv_path}")

    with open(csv_path, newline="", encoding="utf-8-sig") as csvfile:
        reader = csv.DictReader(csvfile)
        if reader.fieldnames:
            reader.fieldnames = [h.replace('\ufeff', '') for h in reader.fieldnames]
        for row in reader:
            name = (row.get("Name") or "").strip()
            type_ = (row.get("Type") or "").strip().lower()
            addr_raw = (row.get("Address") or "").strip()

            m = re.search(r"(\d+)", addr_raw)
            if not m:
                continue
            addr = int(m.group(1))

            key = _normalize_name(name)
            if type_ == "input":
                inputs[key] = {"orig": name, "addr": addr}
            elif type_ == "output":
                outputs[key] = {"orig": name, "addr": addr}

    return inputs, outputs


def resolve_tag(name: str, mapping: Dict[str, dict]) -> int:
    """Resolve um nome lógico para o endereço numérico"""
    key = _normalize_name(name)
    if key not in mapping:
        raise KeyError(f"Tag não encontrada: '{name}' (normalizado: '{key}')")
    return mapping[key]["addr"]


# ---------------------------------------------------------------------------
# Funções de I/O Modbus
# ---------------------------------------------------------------------------

def read_input(client: ModbusTcpClient, addr: int, default: int = 0) -> int:
    """Lê um input digital (coil/input)"""
    try:
        result = client.read_discrete_inputs(address=addr, count=1)
        if not result.isError():
            return int(result.bits[0])
    except Exception:
        pass
    return default


def read_holding(client: ModbusTcpClient, addr: int, default: int = 0) -> int:
    """Lê um registro de holding"""
    try:
        result = client.read_holding_registers(address=addr, count=1)
        if result.isError():
            return default
        return result.registers[0]
    except Exception:
        return default


def write_coil(client: ModbusTcpClient, addr: int, value: int, debug: bool = False) -> None:
    """Escreve um coil (saída digital)"""
    try:
        client.write_coil(address=addr, value=bool(value))
        if debug:
            print(f"  [COIL] Addr {addr} = {value}")
    except Exception as e:
        print(f"[ERRO] Falha ao escrever coil {addr}: {e}")


def write_coils(client: ModbusTcpClient, addrs: List[int], value: int) -> None:
    """Escreve múltiplos coils com o mesmo valor"""
    for addr in addrs:
        write_coil(client, addr, value)


# ---------------------------------------------------------------------------
# Estado do Emitter
# ---------------------------------------------------------------------------

class EmitterState(Enum):
    """Estados do ciclo de emissão"""
    IDLE = "IDLE"
    EMITTING_CONTAINER = "EMITTING_CONTAINER"
    EMITTING_PRODUCT = "EMITTING_PRODUCT"
    CONVEYOR_RUNNING = "CONVEYOR_RUNNING"
    WAITING_FOR_S2_CLEAR = "WAITING_FOR_S2_CLEAR"


@dataclass
class EmitterLine:
    """Controla uma linha de alimentação completa"""
    name: str
    sensor_2_addr: int              # Sensor S2 (indica caixa no final)
    emitter_container_addr: int     # Emitter de container
    emitter_product_addr: int       # Emitter de produto
    conveyor_addrs: List[int]       # Endereços das esteiras

    state: EmitterState = EmitterState.IDLE
    prev_s2: int = 0
    emit_start_time: Optional[float] = None

    # Tempos de emissão (em segundos)
    container_emit_time: float = 0.5
    product_emit_time: float = 0.5


def update_emitter_line(client: ModbusTcpClient, emitter: EmitterLine, now: float) -> None:
    """
    Ciclo de emissão contínua:
    - Quando S2 desliga (1→0), volta para IDLE
    - No IDLE, imediatamente emite container
    - Continua o ciclo: container → produto → esteira → S2 ativa → esteira desliga
    - Aguarda S2 desligar para repetir
    """
    s2 = read_input(client, emitter.sensor_2_addr)

    # Se S2 desligou (transição 1→0), volta para IDLE para emitir próxima caixa
    if s2 == 0 and emitter.prev_s2 == 1:
        emitter.state = EmitterState.IDLE

    if emitter.state == EmitterState.IDLE:
        # Inicia novo ciclo: emite container
        emitter.state = EmitterState.EMITTING_CONTAINER
        emitter.emit_start_time = now
        write_coil(client, emitter.emitter_container_addr, 1)

    elif emitter.state == EmitterState.EMITTING_CONTAINER:
        # Após emitir container, desliga e emite produto
        if now - emitter.emit_start_time >= emitter.container_emit_time:
            write_coil(client, emitter.emitter_container_addr, 0)
            emitter.state = EmitterState.EMITTING_PRODUCT
            emitter.emit_start_time = now
            write_coil(client, emitter.emitter_product_addr, 1)

    elif emitter.state == EmitterState.EMITTING_PRODUCT:
        # Após emitir produto, desliga emitter e LIGA ESTEIRA
        if now - emitter.emit_start_time >= emitter.product_emit_time:
            write_coil(client, emitter.emitter_product_addr, 0)
            emitter.state = EmitterState.CONVEYOR_RUNNING
            # Liga todas as esteiras dessa linha
            write_coils(client, emitter.conveyor_addrs, 1)

    elif emitter.state == EmitterState.CONVEYOR_RUNNING:
        # Aguarda S2 ligar (caixa chegou no final)
        if s2 == 1 and emitter.prev_s2 == 0:
            # Desliga esteira quando S2 ativa
            write_coils(client, emitter.conveyor_addrs, 0)
            emitter.state = EmitterState.WAITING_FOR_S2_CLEAR

    elif emitter.state == EmitterState.WAITING_FOR_S2_CLEAR:
        # Aguarda S2 desligar - será detectado no início da função
        pass

    emitter.prev_s2 = s2


def build_emitter_lines(inputs_map: Dict[str, dict], outputs_map: Dict[str, dict]) -> List[EmitterLine]:
    """Cria os controladores de emissão para as 3 linhas"""
    def inp(name: str) -> int:
        return resolve_tag(name, inputs_map)

    def out(name: str) -> int:
        return resolve_tag(name, outputs_map)

    emitters = [
        EmitterLine(
            name="Linha Verde",
            sensor_2_addr=inp("Sensor_2_Caixote_Verde"),
            emitter_container_addr=out("Emitter_Container_Verde"),
            emitter_product_addr=out("Emitter_Product_Verde"),
            conveyor_addrs=[
                out("Caixote_Verde_Conveyor_1"),
                out("Caixote_Verde_Conveyor_2"),
                out("Caixote_Verde_Conveyor_3"),
                out("Caixote_Verde_Conveyor_4"),
            ],
        ),
        EmitterLine(
            name="Linha Azul",
            sensor_2_addr=inp("Sensor_2_Caixote_Azul"),
            emitter_container_addr=out("Emitter_Container_Azul"),
            emitter_product_addr=out("Emitter_Product_Azul"),
            conveyor_addrs=[
                out("Caixote_Azul_Conveyor_1"),
                out("Caixote_Azul_Conveyor_2"),
            ],
        ),
        EmitterLine(
            name="Linha Vazio",
            sensor_2_addr=inp("Sensor_2_Caixote_Vazio"),
            emitter_container_addr=out("Emitter_Container_Cinza"),
            emitter_product_addr=out("Emitter_Product_Cinza"),
            conveyor_addrs=[
                out("Caixote_Vazio_Conveyor_1"),
                out("Caixote_Vazio_Conveyor_2"),
                out("Caixote_Vazio_Conveyor_3"),
                out("Caixote_Vazio_Conveyor_4"),
            ],
        ),
    ]

    return emitters


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Módulo de Alimentação Contínua (Emitter)")
    parser.add_argument("--host", default="127.0.0.1", help="IP do servidor Modbus")
    parser.add_argument("--port", type=int, default=5020, help="Porta do servidor Modbus")
    parser.add_argument("--csv", default="factory_tags.csv", help="Arquivo de mapeamento CSV")
    args = parser.parse_args()

    # Carrega mapeamento
    try:
        inputs_map, outputs_map = load_factoryio_map(args.csv)
    except FileNotFoundError as e:
        print(f"[ERRO] {e}")
        return

    # Conecta ao servidor Modbus
    client = ModbusTcpClient(args.host, port=args.port)
    if not client.connect():
        return

    # Cria linhas de emissão
    emitters = build_emitter_lines(inputs_map, outputs_map)

    # Arquivo de estado compartilhado
    import json
    SYSTEM_STATE_FILE = "system_state.json"

    def read_system_state() -> bool:
        """Lê o estado do sistema do arquivo JSON"""
        try:
            if os.path.exists(SYSTEM_STATE_FILE):
                with open(SYSTEM_STATE_FILE, 'r') as f:
                    state = json.load(f)
                    return state.get("running", False)
        except Exception:
            pass
        return False

    # Loop principal
    try:
        prev_state = False
        while True:
            now = time.time()

            # Lê estado do sistema do arquivo compartilhado
            system_started = read_system_state()

            # Detecta mudança de estado
            if system_started != prev_state:
                prev_state = system_started

            # Atualiza cada linha de emissão apenas se sistema iniciado
            if system_started:
                for emitter in emitters:
                    update_emitter_line(client, emitter, now)

            time.sleep(SCAN_INTERVAL)

    except KeyboardInterrupt:
        # Desliga tudo
        for emitter in emitters:
            write_coil(client, emitter.emitter_container_addr, 0)
            write_coil(client, emitter.emitter_product_addr, 0)
            write_coils(client, emitter.conveyor_addrs, 0)
        client.close()


if __name__ == "__main__":
    main()
