"""
Módulo de Turntable (Transferência de Caixas)
=============================================

Responsabilidade: Transferir caixas Verde, Azul e Vazia através do Turntable 1

Momento 1: Transferência da Caixa Verde
- Turn liga quando TODOS os S2 estão ativos
- Aguarda Turntable 1 (Limit 90)
- Liga Conveyor_Verde_4 + Roll(+) quando Limit 90 ativa
- Aguarda Back Limit ativar
- Desliga Turn e os atores
- Liga Input_Conveyor_0 + Roll(-) para descarregar
- Desliga Roll(-) quando Back Limit desativa

Comunicação via Modbus TCP com Factory I/O
"""

import time
import argparse
import csv
import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

try:
    from pymodbus.client import ModbusTcpClient
except ImportError:
    from pymodbus.client.sync import ModbusTcpClient


UNIT = 1  # Slave ID padrão
SCAN_INTERVAL = 0.05  # 50ms entre leituras


# ---------------------------------------------------------------------------
# Utilitários de mapeamento (CSV do Factory I/O)
# ---------------------------------------------------------------------------

def _normalize_name(name: str) -> str:
    """Normaliza nomes para busca no dicionário"""
    if name is None:
        return ""
    name = name.replace("\\ufeff", "").strip().lower()
    name = re.sub(r"[^a-z0-9]+", "", name)
    return name


def load_factoryio_map(csv_path: str = "factory_tags.csv") -> Tuple[Dict[str, dict], Dict[str, dict]]:
    """
    Lê o CSV exportado do Factory I/O e separa entradas e saídas.
    Retorna dois dicionários: inputs_map e outputs_map
    """
    inputs: Dict[str, dict] = {}
    outputs: Dict[str, dict] = {}

    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Arquivo de mapeamento CSV não encontrado: {csv_path}")

    with open(csv_path, newline="", encoding="utf-8-sig") as csvfile:
        reader = csv.DictReader(csvfile)
        if reader.fieldnames:
            reader.fieldnames = [h.replace('\ufeff', '') for h in reader.fieldnames]
        for row in reader:
            name = (row.get("Name") or "").strip()
            type_ = (row.get("Type") or "").strip().lower()
            addr_raw = (row.get("Address") or "").strip()

            m = re.search(r"(\d+)", addr_raw)
            if not m:
                continue
            addr = int(m.group(1))

            key = _normalize_name(name)
            if type_ == "input":
                inputs[key] = {"orig": name, "addr": addr}
            elif type_ == "output":
                outputs[key] = {"orig": name, "addr": addr}

    return inputs, outputs


def resolve_tag(name: str, mapping: Dict[str, dict]) -> int:
    """Resolve um nome lógico para o endereço numérico"""
    key = _normalize_name(name)
    if key not in mapping:
        raise KeyError(f"Tag não encontrada: '{name}' (normalizado: '{key}')")
    return mapping[key]["addr"]


# ---------------------------------------------------------------------------
# Funções de I/O Modbus
# ---------------------------------------------------------------------------

def read_input(client: ModbusTcpClient, addr: int, default: int = 0) -> int:
    """Lê um input digital (coil/input)"""
    try:
        result = client.read_discrete_inputs(address=addr, count=1)
        if not result.isError():
            return int(result.bits[0])
    except Exception:
        pass
    return default


def read_holding(client: ModbusTcpClient, addr: int, default: int = 0) -> int:
    """Lê um registro de holding"""
    try:
        result = client.read_holding_registers(address=addr, count=1)
        if result.isError():
            return default
        return result.registers[0]
    except Exception:
        return default


def write_coil(client: ModbusTcpClient, addr: int, value: int, debug: bool = False) -> None:
    """Escreve um coil (saída digital). Imprime apenas COILs 16, 17, 18"""
    try:
        client.write_coil(address=addr, value=bool(value))
        # Monitora apenas COILs 16 (Turn), 17 (Roll+), 18 (Roll-)
        if addr in [16, 17, 18]:
            coil_names = {16: "COIL 16 (Turn)", 17: "COIL 17 (Roll+)", 18: "COIL 18 (Roll-)"}
            status = "ACIONADO" if value == 1 else "DESLIGADO"
            print(f"[{coil_names[addr]}] {status}")
    except Exception:
        pass


def write_coils(client: ModbusTcpClient, addrs: List[int], value: int) -> None:
    """Escreve múltiplos coils com o mesmo valor"""
    for addr in addrs:
        write_coil(client, addr, value)


# ---------------------------------------------------------------------------
# Estado do Turntable
# ---------------------------------------------------------------------------

class TurntableState(Enum):
    """Estados do ciclo de transferência do Turntable"""
    IDLE = "IDLE"
    WAITING_FOR_ALL_S2 = "WAITING_FOR_ALL_S2"

    # Momento 1: Caixa Verde
    MOMENTO1_TURNING = "MOMENTO1_TURNING"
    MOMENTO1_TRANSFERRING = "MOMENTO1_TRANSFERRING"
    MOMENTO1_RETURN_TO_HOME = "MOMENTO1_RETURN_TO_HOME"
    MOMENTO1_UNLOADING = "MOMENTO1_UNLOADING"

    # Momento 2: Caixa Azul
    MOMENTO2_CHECK_EMPTY = "MOMENTO2_CHECK_EMPTY"
    MOMENTO2_TRANSFERRING = "MOMENTO2_TRANSFERRING"
    MOMENTO2_UNLOADING = "MOMENTO2_UNLOADING"

    # Momento 3: Caixa Vazia
    MOMENTO3_CHECK_EMPTY = "MOMENTO3_CHECK_EMPTY"
    MOMENTO3_TURNING = "MOMENTO3_TURNING"
    MOMENTO3_TRANSFERRING = "MOMENTO3_TRANSFERRING"
    MOMENTO3_RETURN_TO_HOME = "MOMENTO3_RETURN_TO_HOME"
    MOMENTO3_UNLOADING = "MOMENTO3_UNLOADING"


@dataclass
class TurntableController:
    """Controla o Turntable 1 para transferência de caixas"""

    # Sensores S2 das linhas
    s2_verde_addr: int
    s2_azul_addr: int
    s2_vazio_addr: int

    # Sensores do Turntable 1
    turntable_limit_0_addr: int         # Limit 0° (posição inicial)
    turntable_limit_90_addr: int        # Limit 90°
    turntable_front_limit_addr: int     # Front Limit
    turntable_back_limit_addr: int      # Back Limit

    # Atuadores do Turntable 1
    turntable_turn_addr: int            # Turn
    turntable_roll_plus_addr: int       # Roll(+)
    turntable_roll_minus_addr: int      # Roll(-)

    # Esteiras
    caixote_verde_conveyor_4_addr: int  # Verde Conveyor 4
    caixote_azul_conveyor_2_addr: int   # Azul Conveyor 2
    caixote_vazio_conveyor_4_addr: int  # Vazio Conveyor 4
    input_conveyor_0_addr: int          # Input Conveyor 0

    state: TurntableState = TurntableState.IDLE
    prev_s2_verde: int = 0
    prev_s2_azul: int = 0
    prev_s2_vazio: int = 0
    prev_limit_0: int = 0
    prev_limit_90: int = 0
    prev_front_limit: int = 0
    prev_back_limit: int = 0

    action_start_time: Optional[float] = None
    momento3_unloading_roll_minus_activated: bool = False  # Guard para Coil 18 em MOMENTO3_UNLOADING
    prev_state: TurntableState = TurntableState.IDLE  # Rastreia estado anterior


def update_turntable(client: ModbusTcpClient, turntable: TurntableController, now: float) -> None:
    """
    Ciclo completo de transferência do Turntable 1 com 3 momentos:

    Momento 1: Caixa Verde (Usa Turn + Limit 90)
    Momento 2: Caixa Azul (Sem Turn, posição inicial)
    Momento 3: Caixa Vazia (Usa Turn + Limit 90, outro lado)
    """

    # Lê todos os sensores
    s2_verde = read_input(client, turntable.s2_verde_addr)
    s2_azul = read_input(client, turntable.s2_azul_addr)
    s2_vazio = read_input(client, turntable.s2_vazio_addr)
    limit_0 = read_input(client, turntable.turntable_limit_0_addr)
    limit_90 = read_input(client, turntable.turntable_limit_90_addr)
    front_limit = read_input(client, turntable.turntable_front_limit_addr)
    back_limit = read_input(client, turntable.turntable_back_limit_addr)
    sensor_write = read_input(client, 41)  # Sensor_Write no Input 41
    input_start_sensor = read_input(client, 18)  # Input_Start_Sensor no Input 18

    if turntable.state == TurntableState.IDLE:
        if s2_verde == 1 and s2_azul == 1 and s2_vazio == 1:
            turntable.state = TurntableState.WAITING_FOR_ALL_S2

    elif turntable.state == TurntableState.WAITING_FOR_ALL_S2:
        write_coil(client, turntable.turntable_turn_addr, 1)
        turntable.state = TurntableState.MOMENTO1_TURNING
        turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO1_TURNING:
        if limit_90 == 1 and turntable.prev_limit_90 == 0:
            print(f"[DEBUG] MOMENTO 1: Turntable Limit 90 acionado → Caixote_Verde_Conveyor_4 ligada")
            write_coil(client, turntable.caixote_verde_conveyor_4_addr, 1)
            write_coil(client, turntable.turntable_roll_minus_addr, 1)
            turntable.state = TurntableState.MOMENTO1_TRANSFERRING
            turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO1_TRANSFERRING:
        if back_limit == 1 and turntable.prev_back_limit == 0:
            write_coil(client, turntable.caixote_verde_conveyor_4_addr, 0)
            write_coil(client, turntable.turntable_roll_minus_addr, 0)
            turntable.state = TurntableState.MOMENTO1_RETURN_TO_HOME
            turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO1_RETURN_TO_HOME:
        write_coil(client, turntable.turntable_turn_addr, 0)
        turntable.state = TurntableState.MOMENTO1_UNLOADING
        turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO1_UNLOADING:
        if limit_0 == 1 and turntable.prev_limit_0 == 0:
            write_coil(client, turntable.turntable_roll_minus_addr, 1)
            print(f"[DEBUG] MOMENTO 1 UNLOAD LINHA 257")

        if back_limit == 0 and front_limit == 0 and sensor_write == 0 and input_start_sensor == 0:
            write_coil(client, turntable.turntable_roll_minus_addr, 0)
            print(f"[DEBUG] MOMENTO 1 → MOMENTO 2: Transição de estados")
            turntable.state = TurntableState.MOMENTO2_CHECK_EMPTY
            turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO2_CHECK_EMPTY:
        if back_limit == 0 and front_limit == 0:
            turntable.state = TurntableState.MOMENTO2_TRANSFERRING
            turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO2_TRANSFERRING:
        # Acionamento ocorre apenas na PRIMEIRA entrada neste estado
        if turntable.prev_back_limit == 0:  # Só executa se não estava em TRANSFERRING antes
            write_coil(client, turntable.caixote_azul_conveyor_2_addr, 1)
            write_coil(client, turntable.turntable_roll_minus_addr, 1)
            print(f"[DEBUG] MOMENTO2_TRANSFERRING linha 277")

        if back_limit == 1 and turntable.prev_back_limit == 0:
            write_coil(client, turntable.caixote_azul_conveyor_2_addr, 0)
            turntable.state = TurntableState.MOMENTO2_UNLOADING
            turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO2_UNLOADING:
        # Coil 18 já foi acionado em MOMENTO2_TRANSFERRING
        # Input_Conveyor_0 já está ligado desde o botão START, não precisa reativar aqui

        if back_limit == 0 and front_limit == 0 and sensor_write == 0 and input_start_sensor == 0:
            write_coil(client, turntable.turntable_roll_minus_addr, 0)
            print(f"[DEBUG] MOMENTO 2 → MOMENTO 3: Transição de estados")
            turntable.state = TurntableState.MOMENTO3_CHECK_EMPTY
            turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO3_CHECK_EMPTY:
        write_coil(client, turntable.turntable_turn_addr, 1)
        turntable.state = TurntableState.MOMENTO3_TURNING
        turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO3_TURNING:
        if limit_90 == 1 and turntable.prev_limit_90 == 0:
            print(f"[DEBUG] MOMENTO 3: Turntable Limit 90 acionado → Caixote_Vazio_Conveyor_4 ligada")
            write_coil(client, turntable.caixote_vazio_conveyor_4_addr, 1)
            write_coil(client, turntable.turntable_roll_plus_addr, 1)
            turntable.state = TurntableState.MOMENTO3_TRANSFERRING
            turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO3_TRANSFERRING:
        # Acionamento ocorre apenas na PRIMEIRA entrada neste estado
        if turntable.prev_front_limit == 0:  # Só executa se não estava em TRANSFERRING antes
            write_coil(client, turntable.caixote_vazio_conveyor_4_addr, 1)
            write_coil(client, turntable.turntable_roll_plus_addr, 1)

        if front_limit == 1 and turntable.prev_front_limit == 0:
            write_coil(client, turntable.turntable_turn_addr, 0)
            write_coil(client, turntable.caixote_vazio_conveyor_4_addr, 0)
            write_coil(client, turntable.turntable_roll_plus_addr, 0)
            turntable.state = TurntableState.MOMENTO3_RETURN_TO_HOME
            turntable.momento3_unloading_roll_minus_activated = False  # Reset ao entrar em MOMENTO3_RETURN_TO_HOME
            turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO3_RETURN_TO_HOME:
        if limit_0 == 1 and turntable.prev_limit_0 == 0:
            write_coil(client, turntable.turntable_roll_minus_addr, 1)
            print(f"[DEBUG] MOMENTO 3 RETURN_TO_HOME: Limit 0 acionado, ejetando com RollMINUS")
            turntable.state = TurntableState.MOMENTO3_UNLOADING
            turntable.action_start_time = now

    elif turntable.state == TurntableState.MOMENTO3_UNLOADING:
        # RollMINUS já foi acionado em MOMENTO3_RETURN_TO_HOME
        # Aguarda todos os sensores zerados para confirmar ejeção completa
        if back_limit == 0 and front_limit == 0 and sensor_write == 0 and input_start_sensor == 0:
            write_coil(client, turntable.turntable_roll_minus_addr, 0)
            print(f"[DEBUG] MOMENTO 3 → IDLE: Caixa totalmente ejetada, fim do ciclo")
            turntable.momento3_unloading_roll_minus_activated = False
            turntable.state = TurntableState.IDLE

    # Atualiza estados anteriores
    turntable.prev_s2_verde = s2_verde
    turntable.prev_s2_azul = s2_azul
    turntable.prev_s2_vazio = s2_vazio
    turntable.prev_limit_0 = limit_0
    turntable.prev_limit_90 = limit_90
    turntable.prev_front_limit = front_limit
    turntable.prev_back_limit = back_limit
    turntable.prev_state = turntable.state


def build_turntable_controller(inputs_map: Dict[str, dict], outputs_map: Dict[str, dict]) -> TurntableController:
    """Cria o controlador do Turntable 1"""

    def inp(name: str) -> int:
        return resolve_tag(name, inputs_map)

    def out(name: str) -> int:
        return resolve_tag(name, outputs_map)

    turntable = TurntableController(
        # Sensores S2 das 3 linhas
        s2_verde_addr=inp("Sensor_2_Caixote_Verde"),
        s2_azul_addr=inp("Sensor_2_Caixote_Azul"),
        s2_vazio_addr=inp("Sensor_2_Caixote_Vazio"),

        # Sensores Turntable 1
        turntable_limit_0_addr=inp("Turntable 1 (Limit 0)"),
        turntable_limit_90_addr=inp("Turntable 1 (Limit 90)"),
        turntable_front_limit_addr=inp("Turntable 1 (Front Limit)"),
        turntable_back_limit_addr=inp("Turntable 1 (Back Limit)"),

        # Atuadores Turntable 1
        turntable_turn_addr=out("Turntable 1 Turn"),
        turntable_roll_plus_addr=out("Turntable 1 RollPLUS"),
        turntable_roll_minus_addr=out("Turntable 1 RollMINUS"),

        # Esteiras das 3 linhas
        caixote_verde_conveyor_4_addr=out("Caixote_Verde_Conveyor_4"),
        caixote_azul_conveyor_2_addr=out("Caixote_Azul_Conveyor_2"),
        caixote_vazio_conveyor_4_addr=out("Caixote_Vazio_Conveyor_4"),
        input_conveyor_0_addr=out("Input_Conveyor_0"),
    )

    return turntable


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Módulo de Turntable (Transferência)")
    parser.add_argument("--host", default="127.0.0.1", help="IP do servidor Modbus")
    parser.add_argument("--port", type=int, default=5020, help="Porta do servidor Modbus")
    parser.add_argument("--csv", default="factory_tags.csv", help="Arquivo de mapeamento CSV")
    args = parser.parse_args()

    # Carrega mapeamento
    try:
        inputs_map, outputs_map = load_factoryio_map(args.csv)
    except FileNotFoundError:
        return

    # Conecta ao servidor Modbus
    client = ModbusTcpClient(args.host, port=args.port)
    if not client.connect():
        return

    # Cria controlador do Turntable
    turntable = build_turntable_controller(inputs_map, outputs_map)

    # Arquivo de estado compartilhado
    import json
    SYSTEM_STATE_FILE = "system_state.json"

    def read_system_state() -> bool:
        """Lê o estado do sistema do arquivo JSON"""
        try:
            if os.path.exists(SYSTEM_STATE_FILE):
                with open(SYSTEM_STATE_FILE, 'r') as f:
                    state = json.load(f)
                    return state.get("running", False)
        except Exception:
            pass
        return False

    # Loop principal
    try:
        prev_state = False
        while True:
            now = time.time()

            # Lê estado do sistema do arquivo compartilhado
            system_started = read_system_state()

            # Detecta mudança de estado
            if system_started != prev_state:
                prev_state = system_started

            # Atualiza turntable apenas se sistema iniciado
            if system_started:
                update_turntable(client, turntable, now)

            time.sleep(SCAN_INTERVAL)

    except KeyboardInterrupt:
        write_coil(client, turntable.turntable_turn_addr, 0)
        write_coil(client, turntable.turntable_roll_plus_addr, 0)
        write_coil(client, turntable.turntable_roll_minus_addr, 0)
        write_coil(client, turntable.caixote_verde_conveyor_4_addr, 0)
        client.close()


if __name__ == "__main__":
    main()
