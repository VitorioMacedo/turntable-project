"""
Script Principal (Main Orchestrator)
====================================

Responsabilidade: Orquestar todos os módulos independentes
- Controla botão START/STOP para TODA A FÁBRICA
- Emitter Module: Alimentação contínua de caixas
- Turntable Module: Transferência com turntables
- Handler Module: Controle do manejador
- Picking Module: Pick & Place

Cada módulo roda em um processo paralelo, se comunicando via:
- Modbus TCP (com Factory I/O)
- Arquivo de estado compartilhado (system_state.json)

Uso:
    python3 main.py --host 127.0.0.1 --port 5020 --csv factory_tags.csv
"""

import subprocess
import sys
import time
import argparse
import signal
import json
import os
from typing import List, Optional

try:
    from pymodbus.client import ModbusTcpClient
except ImportError:
    from pymodbus.client.sync import ModbusTcpClient


SYSTEM_STATE_FILE = "system_state.json"


def read_input(client: ModbusTcpClient, addr: int, default: int = 0) -> int:
    """Lê um input digital"""
    try:
        result = client.read_discrete_inputs(address=addr, count=1)
        if not result.isError():
            return int(result.bits[0])
    except Exception:
        pass
    return default


def write_coil(client: ModbusTcpClient, addr: int, value: int) -> None:
    """Escreve um coil (saída digital)"""
    try:
        client.write_coil(address=addr, value=bool(value))
    except Exception:
        pass


def write_system_state(running: bool) -> None:
    """Escreve o estado do sistema em arquivo JSON"""
    state = {"running": running, "timestamp": time.time()}
    try:
        with open(SYSTEM_STATE_FILE, 'w') as f:
            json.dump(state, f)
    except Exception as e:
        print(f"[ERRO] Falha ao escrever estado: {e}")


def disable_all_outputs(client: ModbusTcpClient) -> None:
    """Desliga todos os coils/outputs quando o script inicia"""
    if not client:
        return

    # Lista de todos os coils que devem ser desligados
    all_coils = [
        0, 1, 2, 3, 4, 5,           # Emitters e Conveyors Verde
        6, 7, 8, 9,                 # Emitters e Conveyors Azul
        10, 11, 12, 13, 14, 15,     # Emitters e Conveyors Cinza/Vazio
        16, 17, 18, 19, 20, 21, 22, 23, 24,  # Turntables
        25, 26,                     # Input Conveyors
        29, 30, 34, 35, 36,         # Conveyor Access e Delivery
        43                          # LED Status
    ]

    print("[INICIALIZAÇÃO] Desligando todos os outputs...")
    for coil in all_coils:
        write_coil(client, coil, 0)


def read_system_state() -> bool:
    """Lê o estado do sistema do arquivo JSON"""
    try:
        if os.path.exists(SYSTEM_STATE_FILE):
            with open(SYSTEM_STATE_FILE, 'r') as f:
                state = json.load(f)
                return state.get("running", False)
    except Exception:
        pass
    return False


class ModuleManager:
    """Gerencia os processos dos módulos"""

    def __init__(self, host: str, port: int, csv_path: str):
        self.host = host
        self.port = port
        self.csv_path = csv_path
        self.processes: List[subprocess.Popen] = []
        self.running = True

        # Conecta ao Modbus para monitorar botões
        self.client = ModbusTcpClient(host, port=port)
        if not self.client.connect():
            print("[AVISO] Falha ao conectar ao Modbus para monitorar botões")
            self.client = None

        # Estado do sistema
        self.system_started = False
        self.prev_start_button = 0
        self.prev_emergency_stop = 0

        # Reseta o arquivo de estado quando o script inicia
        write_system_state(False)

        # Desliga todos os outputs/coils quando o script inicia
        disable_all_outputs(self.client)

    def start_module(self, module_name: str, module_file: str, enabled: bool = True) -> Optional[subprocess.Popen]:
        """Inicia um módulo como subprocess"""
        if not enabled:
            print(f"[{module_name}] Desabilitado (pulando)")
            return None

        cmd = [
            sys.executable, module_file,
            "--host", self.host,
            "--port", str(self.port),
            "--csv", self.csv_path
        ]

        print(f"[{module_name}] Iniciando... ({' '.join(cmd)})")
        try:
            # Get the directory where this script is located
            script_dir = os.path.dirname(os.path.abspath(__file__))
            process = subprocess.Popen(cmd, cwd=script_dir)
            self.processes.append(process)
            print(f"[{module_name}] PID: {process.pid}")
            return process
        except Exception as e:
            print(f"[{module_name}] ERRO ao iniciar: {e}")
            return None

    def start_all_modules(self, enable_emitter=True, enable_turntable=True,
                         enable_handler=False, enable_picking=False):
        """Inicia todos os módulos habilitados"""
        print("\n" + "="*70)
        print("INICIANDO MÓDULOS")
        print("="*70 + "\n")

        self.start_module(
            "EMITTER MODULE",
            "emitter_module.py",
            enabled=enable_emitter
        )
        time.sleep(1)  # Aguarda inicialização do primeiro módulo

        self.start_module(
            "TURNTABLE MODULE",
            "turntable_module.py",
            enabled=enable_turntable
        )
        time.sleep(1)

        self.start_module(
            "HANDLER MODULE",
            "handler_module.py",
            enabled=enable_handler
        )
        time.sleep(1)

        self.start_module(
            "PICKING MODULE",
            "picking_module.py",
            enabled=enable_picking
        )

        print("\n" + "="*70)
        print(f"TODOS OS MÓDULOS INICIADOS ({len(self.processes)} processos)")
        print("="*70 + "\n")

    def monitor_buttons(self):
        """Monitora botões START/STOP e atualiza estado do sistema"""
        if not self.client:
            return

        # Lê botão START (Input 34)
        start_button = read_input(self.client, 34)

        # Detecta transição 0→1 (botão pressionado)
        if start_button == 1 and self.prev_start_button == 0:
            self.system_started = not self.system_started
            status = "INICIADO" if self.system_started else "PARADO"
            print(f"\n[BOTÃO] Sistema {status} - Escrevendo estado para módulos...")
            write_system_state(self.system_started)
            # Liga/desliga LED de status (Coil 43)
            write_coil(self.client, 43, 1 if self.system_started else 0)
            # Liga/desliga Input_Conveyor_0 (Coil 25)
            write_coil(self.client, 25, 1 if self.system_started else 0)
            # Liga/desliga Input_Conveyor_1 (Coil 26)
            write_coil(self.client, 26, 1 if self.system_started else 0)
            # Liga/desliga TurnTable 2 RollMINUS (Coil 21)
            write_coil(self.client, 21, 1 if self.system_started else 0)
            # Liga/desliga Esteira Dispatch (Coil 31)
            write_coil(self.client, 31, 1 if self.system_started else 0)
            # Liga/desliga TurnTable 3 RollMINUS (Coil 24)
            write_coil(self.client, 24, 1 if self.system_started else 0)
            # Liga/desliga Conveyor Delivery (Coil 36)
            write_coil(self.client, 36, 1 if self.system_started else 0)
            # Liga/desliga Remover 0 (Coil 45)
            write_coil(self.client, 45, 1 if self.system_started else 0)

        self.prev_start_button = start_button

        # Lê botão EMERGENCY STOP (Input 39)
        emergency_stop = read_input(self.client, 39)

        # Detecta transição 0→1 (botão pressionado)
        if emergency_stop == 1 and self.prev_emergency_stop == 0:
            self.system_started = False
            print(f"\n[EMERGENCY STOP] Sistema PARADO IMEDIATAMENTE!")
            write_system_state(False)
            # Desliga LED de status (Coil 43)
            write_coil(self.client, 43, 0)
            # Desliga Input_Conveyor_0 (Coil 25)
            write_coil(self.client, 25, 0)
            # Desliga Input_Conveyor_1 (Coil 26)
            write_coil(self.client, 26, 0)
            # Desliga TurnTable 2 RollMINUS (Coil 21)
            write_coil(self.client, 21, 0)
            # Desliga Esteira Dispatch (Coil 31)
            write_coil(self.client, 31, 0)
            # Desliga TurnTable 3 RollMINUS (Coil 24)
            write_coil(self.client, 24, 0)
            # Desliga Conveyor Delivery (Coil 36)
            write_coil(self.client, 36, 0)
            # Desliga Remover 0 (Coil 45)
            write_coil(self.client, 45, 0)

        self.prev_emergency_stop = emergency_stop

    def monitor_modules(self):
        """Monitora os processos em execução e botões"""
        try:
            while self.running:
                # Monitora botões START/STOP
                self.monitor_buttons()

                # Verifica se algum processo terminou
                for i, proc in enumerate(self.processes):
                    if proc.poll() is not None:  # Processo terminou
                        print(f"[MONITOR] Processo {proc.pid} terminou (saída: {proc.returncode})")
                        self.processes.pop(i)

                # Se não há processos, sai
                if not self.processes:
                    print("[MONITOR] Todos os processos foram encerrados")
                    break

                time.sleep(0.1)  # Verifica botões a cada 100ms

        except KeyboardInterrupt:
            print("\n[MONITOR] Interrupção recebida")
            self.running = False

    def stop_all_modules(self):
        """Para todos os módulos"""
        print("\n" + "="*70)
        print("ENCERRANDO MÓDULOS")
        print("="*70 + "\n")

        for proc in self.processes:
            try:
                print(f"[ENCERRANDO] Processo {proc.pid}...")
                proc.terminate()
                proc.wait(timeout=5)
                print(f"[OK] Processo {proc.pid} encerrado")
            except subprocess.TimeoutExpired:
                print(f"[FORÇANDO] Matando processo {proc.pid}...")
                proc.kill()
                proc.wait()
            except Exception as e:
                print(f"[ERRO] Ao encerrar {proc.pid}: {e}")

        self.processes.clear()
        print("\n[FINALIZADO] Todos os módulos foram encerrados")


def main():
    parser = argparse.ArgumentParser(
        description="Script Principal - Orquestrador de Módulos",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos:
  # Apenas emitter (alimentação)
  python3 main.py --emitter-only

  # Emitter + Turntable (alimentação + transferência)
  python3 main.py --turntable

  # Todos os módulos
  python3 main.py --all
        """
    )

    parser.add_argument("--host", default="127.0.0.1",
                       help="IP do servidor Modbus (padrão: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=5020,
                       help="Porta do servidor Modbus (padrão: 5020)")
    parser.add_argument("--csv", default="factory_tags.csv",
                       help="Arquivo de mapeamento CSV (padrão: factory_tags.csv)")

    # Opções de módulos
    parser.add_argument("--emitter-only", action="store_true",
                       help="Apenas módulo de alimentação (padrão)")
    parser.add_argument("--turntable", action="store_true",
                       help="Alimentação + Turntable")
    parser.add_argument("--handler", action="store_true",
                       help="Adiciona módulo de Handler")
    parser.add_argument("--picking", action="store_true",
                       help="Adiciona módulo de Pick & Place")
    parser.add_argument("--all", action="store_true",
                       help="Todos os módulos")

    args = parser.parse_args()

    print("\n" + "="*70)
    print("STRAUDINGER - SISTEMA DE CONTROLE MODULAR")
    print("="*70)
    print(f"Host: {args.host}:{args.port}")
    print(f"CSV: {args.csv}")
    print("="*70 + "\n")

    # Determina quais módulos ativar
    enable_emitter = True  # Sempre ativo
    enable_turntable = args.turntable or args.all
    enable_handler = args.handler or args.all
    enable_picking = args.picking or args.all

    # Se nenhuma opção foi especificada, apenas emitter
    if not any([args.emitter_only, args.turntable, args.handler, args.picking, args.all]):
        args.emitter_only = True

    print("[CONFIGURAÇÃO]")
    print(f"  Emitter: {'SIM' if enable_emitter else 'NÃO'}")
    print(f"  Turntable: {'SIM' if enable_turntable else 'NÃO'}")
    print(f"  Handler: {'SIM' if enable_handler else 'NÃO'}")
    print(f"  Picking: {'SIM' if enable_picking else 'NÃO'}")
    print()

    # Cria o gerenciador de módulos
    manager = ModuleManager(args.host, args.port, args.csv)

    # Handler para Ctrl+C
    def signal_handler(sig, frame):
        print("\n[MAIN] Sinal de interrupção recebido")
        manager.stop_all_modules()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    try:
        # Inicia os módulos
        manager.start_all_modules(
            enable_emitter=enable_emitter,
            enable_turntable=enable_turntable,
            enable_handler=enable_handler,
            enable_picking=enable_picking
        )

        # Monitora os processos
        manager.monitor_modules()

    except Exception as e:
        print(f"[ERRO] {e}")
        manager.stop_all_modules()
        sys.exit(1)


if __name__ == "__main__":
    main()
